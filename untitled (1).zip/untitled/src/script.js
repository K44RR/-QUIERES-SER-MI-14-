// Generación de corazones aleatorios
const heartsContainer = document.querySelector('.hearts-container');

for (let i = 0; i < 500; i++) {
    const heart = document.createElement('div');
    heart.classList.add('heart');
    heart.innerHTML = '&#10084;';
    // Posicionamiento aleatorio de los corazones
    heart.style.left = `${Math.random() * 100}%`;
    heart.style.top = `${Math.random() * 100}%`;
    heart.style.animationDuration = `${Math.random() * 3 + 2}s`; // Duración aleatoria de cada corazón
    heartsContainer.appendChild(heart);
}

// Función para mover el botón "No" a una posición aleatoria dentro de la pantalla
document.getElementById("noBtn").addEventListener("mouseover", function() {
    // Calculamos los límites de la pantalla para que no se salga del área visible
    let maxX = window.innerWidth - this.offsetWidth;
    let maxY = window.innerHeight - this.offsetHeight;

    // Generamos una posición aleatoria dentro de esos límites
    let x = Math.random() * maxX;
    let y = Math.random() * maxY;
    
    // Movemos el botón "No" a la nueva posición aleatoria
    this.style.left = `${x}px`;
    this.style.top = `${y}px`;
});

// Función para cuando el usuario hace clic en "Sí"
function aceptar() {
    alert("¡Nos vemos el 14 de febrero! ❤️");
}
